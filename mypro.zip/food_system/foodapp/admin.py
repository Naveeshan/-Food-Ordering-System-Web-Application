from django.contrib import admin

from foodapp.models import User

admin.site.register(User)
